<!DOCTYPE html>
<html>
<head>
    <title>RMS Auto Repairs</title>
</head>
<body>
    <div><?php echo $body; ?></div>
</body>
</html><?php /**PATH /home3/rmsauto5/public_html/IMS/resources/views/emails/email.blade.php ENDPATH**/ ?>