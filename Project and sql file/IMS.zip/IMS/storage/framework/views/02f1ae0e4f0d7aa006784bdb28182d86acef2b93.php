<!DOCTYPE html>
<html>
<head>
    <title>RMS Auto Repairs</title>
</head>
<body>
    <div><?php echo $body; ?></div>
</body>
</html><?php /**PATH /home/rmsautoa/public_html/IMS/resources/views/emails/email.blade.php ENDPATH**/ ?>