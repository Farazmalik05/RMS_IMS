<!DOCTYPE html>
<html>
<head>
    <title>RMS Auto Repairs</title>
</head>
<body>
    <div>{!! $body !!}</div>
</body>
</html>